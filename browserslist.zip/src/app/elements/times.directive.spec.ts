import { TimesDirective } from './times.directive';

describe('TimesDirective', () => {
  it('should create an instance', () => {
    const directive = new TimesDirective();
    expect(directive).toBeTruthy();
  });
});
