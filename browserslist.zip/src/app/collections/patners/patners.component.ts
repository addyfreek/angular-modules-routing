import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-patners',
  templateUrl: './patners.component.html',
  styleUrls: ['./patners.component.css']
})
export class PatnersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
